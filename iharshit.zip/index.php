<!DOCTYPE html>
<html lang="en">
<?php header("Content-Type: text/html; charset=ISO-8859-1"); ?>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"> 


    <title>Harshit - Portfolio </title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans|Josefin+Slab|News+Cycle" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="css/agency.min.css" rel="stylesheet">
	
	<link href='css/rotating-card.css' rel='stylesheet' />
<!--	<link href='css/bootstrap.css' rel='stylesheet' /> -->
	
	    <style>
    html, body {
    max-width: 100%;
    margin: 0;
    background: #fdf6f2 !important;
    font-weight: 400;
    font-family: Josefin Sans,sans-serif,arial,serif !important;
    color:#000000;
      }
	  a{
		  color:#2a6496;
	  }
	 div, a, span,p, h2 {
		 font-family: Josefin Sans,sans-serif,arial,serif !important;
		 font-weight:0px;
	 }
	 .jumbotron{
		 background-color:#ffffff;
		 color:#c11603;
		 font-family: Josefin Sans,sans-serif,arial,serif !important;
		 padding:20px auto  0px;
		 font-weight:10;
	 }
	 
    .portfolioimage{
	  opacity: 0.9;
	  text-align: center;
	  vertical-align: middle;
	  border-radius: 50%;
	  max-width: 80%;
	  display: inline-block;
	  position: relative;
	  margin-top: 10%;
	}
h1,
h2,
h3,
h4,
h5,
h6,
.h1,
.h2,
.h3,
.h4,
.h5,
.h6 {
  font-size:30px;
  font-weight: 500;
  line-height: 1.1;
  color: inherit;
}
 
    </style>

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-default fixed-top" id="mainNav" style="background-color:#ed5565;color:#000;">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">Harshit <i class="fa fa-circle" style="font-size: 10px;"></i> Portfolio</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive" style="background-color:#ed5565;border-radius:10px;">
          <ul class="navbar-nav text-uppercase ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#internships">Internships</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#publications">Publications</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#projects">Projects</a>
            </li>
			    <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#involvements">Involvements</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#resume">CV</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
	
   <!-- From index.php -->
   <div class="container" style="margin-bottom:0px;">
		
		
		 <div class="jumbotron" style="padding:10px;">
		
			<h2 class="text-center">About me</h2> 
			
		</div>
		
		<p> I am Harshit Gujral and I am currently pursuing sixth semester of Information-Technology major from department of Computer Science Engineering & IT at the Jaypee Institute of Information Technology (JIIT), Noida, India. Please find information about my 
		<a href="#internships">
			Internships, 
		</a>
		<a href="#publications">
			Publications, 
		</a>
		<a href="#projects">
			Projects,
		</a>
		<a href="#presentations">
			Presentations,
		</a> and	
		<a href="#involvements">
			Involvements. 
		</a>
		</p>
		
		 <div class="jumbotron" style="padding:10px;">
		
			<h2 class="text-center" id="internships">Internships</h2> 
			
		</div>
		        
		<div class="row" >
        			
	<?php
		include 'mysqlconnect.php'; 
		include 'functions.php';
		
		$ptr=0;
		$query="select * from internship order by sdate desc";

		$query_run=mysqli_query($current,$query);
		if(mysqli_num_rows($query_run)>0){

		while($result=mysqli_fetch_array($query_run)){
			$id=$result['id'];
			$companyName=$result['companyName'];
			$companySummary=$result['companySummary'];
			$designation=$result['designation'];
			$sdate=$result['sdate'];
			$edate=$result['edate'];
			$image=$result['img'];
			$category=$result['category'];
			$location=$result['location'];
			
			
			$query2="select * from internshiptags where internid='".$id."'";
			$query_run2=mysqli_query($current,$query2);
			$tags= array();
			if(mysqli_num_rows($query_run2)>0){
				while($result2=mysqli_fetch_array($query_run2)) {
					$tags[$result2['projectname']]=$result2['projectlink'];
				}
			}
		
			$ptr+=1;
			
			internshipCard($ptr,$image,$companyName,$companySummary,$designation,$sdate,$edate,$category,$location,$tags);
				
		}}
		
		?>
		
	
	</div>
    
	<!-- Publications -->
	
    	 <div class="jumbotron" style="padding:10px;">
		
			<h2 class="text-center" id="publications">Publications</h2> 
			
		</div>
	  
	  <?php
	  $query="select * from publications";

		$query_run=mysqli_query($current,$query);
		if(mysqli_num_rows($query_run)>0){
		$ptr=0;
		while($result=mysqli_fetch_array($query_run)){
			$authors=$result['authors'];
			$title=$result['title'];
			$year=$result['year'];
			$status=$result['status'];
			$publication=$result['publication'];
			$link1=$result['link1'];
			$link1caption=$result['link1caption'];
			$link2=$result['link2'];
			$link2caption=$result['link2caption'];
			
			$str=insertPublication($ptr+1,$authors,$title,$year,$status,$publication,$link1,$link1caption,$link2,$link2caption);
			if ($str!='')
				echo "<p>".$str."</p>";
			$ptr+=1;
			}}
	  
	  ?>
	</div>
    <!-- Projects -->
   
      <div class="container">
			<div class="jumbotron" style="padding:10px;">
				<h2 class="text-center">Projects</h2> 
			</div>
			<?php
			$distinctTags=getDistinctTags($current);
			echo '<div class="row" id="projects"> <div class="col-md-12 text-center"> <font size=4 color="#c11603">';
			$fool=0;
			
			foreach($distinctTags as $tag){
				$stag=str_replace(" ","_",$tag);
				echo '<a href="#projects" style="color:#c11603;"><span id="'.$stag.'">'.$tag.'</span> </a>';
				if (count($distinctTags)-2!=$fool)
					echo " | ";
				$fool+=1;
				
				
			}
			echo "</font></div></div><br/><br/>";
		
			?>
	
        <div class="row">
		
		<!-- Projects -->
		<?php
				
		$query="select * from projects order by sdate desc";

		$query_run=mysqli_query($current,$query);
		if(mysqli_num_rows($query_run)>0){
		$ptr=0;
		while($result=mysqli_fetch_array($query_run)){
			$id=$result['id'];
			$stitle=$result['stitle'];
			$title=$result['title'];
			$twoLine=$result['twoLine'];
			$sdate=$result['sdate'];
			$edate=$result['edate'];
			$image=$result['img'];
			$deployLink=$result['deployLink'];
			$gitLink=$result['gitLink'];
			
			$query2="select * from tags where id='".$id."'";
			$query_run2=mysqli_query($current,$query2);
			$tags= array();
			if(mysqli_num_rows($query_run2)>0){
				while($result2=mysqli_fetch_array($query_run2)) {
					$tags[]=$result2['tag'];
				}
			}
			
			$ptr+=1;
			projectCard($ptr,$image,$title,$stitle,$twoLine,$deployLink,$gitLink, $tags);
				
		}}
		
		
		?>

        </div>
      
	  <!-- Presentations -->
	  <div class="jumbotron" style="padding:10px;" id="presentations">
				<h2 class="text-center">Presentations</h2>
	</div>
	  <?php
	  $query="select * from presentations";

		$query_run=mysqli_query($current,$query);
		if(mysqli_num_rows($query_run)>0){
		$ptr=0;
		while($result=mysqli_fetch_array($query_run)){
			$presented=$result['presented'];
			$name=$result['name'];
			$venue=$result['venue'];
			
			$str=insertPresentation($ptr+1,$presented,$name,$venue);
			if ($str!='')
				echo "<p>".$str."</p>";
			$ptr+=1;
			}}
	  
	  ?>				
	  
	  <!-- Involvements -->
	  <div class="jumbotron" style="padding:10px;"id="involvements">
				<h2 class="text-center">Involvements</h2>
	</div>
	  <?php
	  $query="select * from involvements";

		$query_run=mysqli_query($current,$query);
		if(mysqli_num_rows($query_run)>0){
		$ptr=0;
		while($result=mysqli_fetch_array($query_run)){
			$initial=$result['initial'];
			$designation=$result['designation'];
			$company=$result['company'];
			
			$str=insertInvolvements($ptr+1,$initial,$designation,$company);
			if ($str!='')
				echo "<p>".$str."</p>";
			$ptr+=1;
			}}
	  
	  ?>

   <div class="jumbotron" style="padding:10px;" id="resume">
				<h2 class="text-center">Documents</h2> 
	</div>
			<div class="row text-center">
				<div class="col-md-4">
					<a href="https://drive.google.com/file/d/18U0vPZMbLE4WN5AbNYPSMeHTBm1fJXGS/view?usp=sharing" target="_blank">
						CV
					</a>
				</div>
				<div class="col-md-4">
					<a href="https://drive.google.com/file/d/1pXtly1mhTzr1IsvZgePNJk1NFWKTiD5v/view?usp=sharing target="_blank">
						Research Statement
					</a>
				</div>
				<div class="col-md-4">
					<a href="https://drive.google.com/file/d/1hH63ostgaL7vhDTX7NGJJLbWJohH8En2/view?usp=sharing" target="_blank">
						Publication List
					</a>
					
				</div>
			</div>
  
  
   <div class="jumbotron" style="padding:10px;" id="contact">
				<h2 class="text-center">Contact</h2> 
	</div>
			<p class="text-center"><a href="mailto:harshitgujral12@gmail.com"> email: harshitgujral12@gmail.com </a></p>
	  


    </div>
	
	<!-- end Container -->
   
   <!-- end -->

 
	 

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-md-4">
            <span class="copyright">Copyright &copy; Harshit Gujral 2018</span>
          </div>
          <div class="col-md-4">
            <ul class="list-inline social-buttons">
              <li class="list-inline-item">
                <a href="https://medium.com/@Harshitgujral" target="_blank">
                  <i class="fa fa-medium"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="https://github.com/newtein/" target="_blank">
                  <i class="fa fa-github"></i>
                </a>
              </li>
              <li class="list-inline-item">
                <a href="https://www.linkedin.com/in/harshitgujral/" target="_blank">
                  <i class="fa fa-linkedin"></i>
                </a>
              </li>
            </ul>
          </div>
          <div class="col-md-4">
            <ul class="list-inline quicklinks">
              <li class="list-inline-item">
               <p> Made with <font color="#ed5565"> <i class="fa fa-heart" aria-hidden="true"></i> </font> by harshit</p>
              </li>
         
            </ul>
          </div>
        </div>
      </div>
    </footer> 

    <!-- Portfolio Modals -->


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/agency.min.js"></script>
	
	<?php
		echo "<script type='text/javascript'>";
		
			
			foreach($distinctTags as $tag){
				$stag=str_replace(" ","_",$tag);
			echo '$("#'.$stag.'").click(function(){
					
					$(".All").css("display","none").attr("aria-hidden","true");
					$(".'.$stag.'").show();
			
				});
				';
			}
			echo "</script>";
	

	?>


  </body>

</html>
